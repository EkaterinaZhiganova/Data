sum_function<- function (a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z,aa,bb,cc,dd)#30 objects vector
{
  max_temp <-a # we choose the max value, it is number 1 (a)
  average_temp<-(a+b+c+d+e+f+g+h+i+j+k+l+m+n+o+p+q+r+s+t+u+v+w+x+y+z+aa+bb+cc+dd)/30 # calculation of the average temp
  min_temp <-dd # we choose the min value, it is number 30 (dd)
  print (max_temp)
  print (average_temp)
  print (min_temp)
  return(list (max_temp, average_temp, min_temp))#we remember this three values in the list to use them later
}
